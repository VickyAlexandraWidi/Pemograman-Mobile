package com.VickyAlexandraWidi.forex;

public class Gson {
    public RootModel fromJson ( String s, Class<RootModel> rootModelClass ) {
        return null;
    }
}
