package com.VickyAlexandraWidi.forex;

public class RatesModel
{
    private double AUD, BND, HKD, IDR, XAU, RUB, SGD, USD, JPY, KRW;

    public RatesModel() {}

    public double getAUD() { return AUD; }

    public void setAUD(double AUD) { this.AUD = AUD; }

    public double getBND() { return BND; }

    public void setBND(double BND) { this.BND = BND; }

    public double getHKD() { return HKD; }

    public void setHKD(double HKD) { this.HKD = HKD; }

    public double getIDR() { return IDR; }

    public void setIDR(double IDR) { this.IDR = IDR; }

    public double getXAU() { return XAU; }

    public void setXAU(double XAU) { this.XAU = XAU; }

    public double getRUB() { return RUB; }

    public void setRUB(double RUB) { this.RUB = RUB; }

    public double getSGD() { return SGD; }

    public void setSGD(double SGD) { this.SGD = SGD; }

    public double getUSD() { return USD; }

    public void setUSD(double USD) { this.USD = USD; }

    public double getJPY() { return JPY; }

    public void setJPY(double JPY) { this.JPY = JPY; }

    public double getKRW() { return KRW; }

    public void setKRW(double KRW) { this.KRW = KRW; }
}
