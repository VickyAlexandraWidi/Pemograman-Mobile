package com.randiantero.hotelapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private ImageView _imageview1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _imageview1 = (ImageView) findViewById(R.id.imageView1);

        String imageurl = "https://phinemo.com/wp-content/uploads/2018/01/hotel-tepi-pantai-pangandaran.jpg";
        Picasso.with(this).load(imageurl).into(_imageview1);
    }
}